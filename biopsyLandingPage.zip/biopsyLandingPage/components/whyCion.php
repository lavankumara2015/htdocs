<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .why-cion-container {
            width: 100%;
            height: 12rem;
            background-color: aqua;
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .why-cion-container__center {
            width: 6.81rem;
            height: 6.81rem;
            background-color: #F6F6F6;
            border-radius: 50%;
            position: relative; 
        }
        .dot {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: black;
            position: absolute;
            transition: all 0.5s ease;
            opacity: 0;
            top: 32.5%;
            left: 32.5%;
            transform: translate(-50%, -50%); 
        }
    </style>
</head>
<body>
    <section class="why-cion-container">
        <div class="why-cion-container__center">
            <div class="dot" id="id1"></div>
            <div class="dot" id="id2"></div>
            <div class="dot" id="id3"></div>
            <div class="dot" id="id4"></div>
        </div>
    </section>

<script>
    let centerDiv = document.querySelector('.why-cion-container__center');
    const dots = document.querySelectorAll('.dot');
    let isVisible = false;

    centerDiv.addEventListener("click", () => {
        if (!isVisible) {
            dots.forEach((dot, index) => {
                const angle = (index * Math.PI / 2) + (Math.PI / 4); 
                const radius = 200; 

                const x = Math.cos(angle) * radius;
                const y = Math.sin(angle) * radius;

                dot.style.transform = `translate(${x}px, ${y}px)`;
                dot.style.opacity = 1; 
            });
            isVisible = true;
        } else {
            dots.forEach((dot) => {
        
                dot.style.transform = 'none';
                dot.style.opacity = 0;
            });
            isVisible = false;
        }
    });
</script>
</body>
</html>
