
<section class="biopsy-process-container">

<h2>How is the <span>Biopsy Process Done ?</span></h2>
<div class="biopsy-process-container__text">
 <?php foreach ($biopsyProcess as $items): ?>
       
                <h1 class="biopsy-process-container__h1"><?php echo $items[0]; ?></h1>
                <p class="biopsy-process-container__p"><?php echo $items[1]; ?></p>
     
        <?php endforeach; ?>
        </div>
</section>
