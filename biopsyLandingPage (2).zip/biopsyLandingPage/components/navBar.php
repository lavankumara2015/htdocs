

<nav>
<img src="./assets/cion-logo.webp" alt="cion-logo">
<a href="tel:18001202676"><img src="./assets/Phone-icon-sm.webp" alt="phone-icon"></a> 
<button><a href="tel:18001202676">Contact Us</a></button>
</nav>